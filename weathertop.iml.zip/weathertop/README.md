# play-template-1

This is a sample starter project for this course:

- [Web Development](https://reader.tutors.dev/course/wit-hdip-comp-sci-2023-web-dev-1)
